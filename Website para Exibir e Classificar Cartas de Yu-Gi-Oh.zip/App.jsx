import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Search, Star, Zap, Shield, Sword } from 'lucide-react'
import characterDecksData from './assets/character_decks.json'
import './App.css'

function App() {
  const [selectedCharacter, setSelectedCharacter] = useState(null)
  const [selectedCard, setSelectedCard] = useState(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [characterDecks, setCharacterDecks] = useState({})

  useEffect(() => {
    setCharacterDecks(characterDecksData)
  }, [])

  const characters = Object.keys(characterDecks)
  
  const filteredCards = selectedCharacter 
    ? characterDecks[selectedCharacter]?.filter(card => 
        card.name.toLowerCase().includes(searchTerm.toLowerCase())
      ) || []
    : []

  const getCardTypeIcon = (type) => {
    if (type.includes('Monster')) return <Sword className="w-4 h-4" />
    if (type.includes('Spell')) return <Star className="w-4 h-4" />
    if (type.includes('Trap')) return <Shield className="w-4 h-4" />
    return <Zap className="w-4 h-4" />
  }

  const getCardTypeColor = (type) => {
    if (type.includes('Monster')) return 'bg-orange-500'
    if (type.includes('Spell')) return 'bg-green-500'
    if (type.includes('Trap')) return 'bg-purple-500'
    return 'bg-blue-500'
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-sm border-b border-white/10">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-4xl font-bold text-white text-center mb-2">
            Yu-Gi-Oh! Card Database
          </h1>
          <p className="text-blue-200 text-center">
            Explore cartas organizadas por personagens dos animes Yu-Gi-Oh! e Yu-Gi-Oh! GX
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Character Selection */}
          <div className="lg:col-span-1">
            <Card className="bg-black/20 backdrop-blur-sm border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Personagens</CardTitle>
                <CardDescription className="text-blue-200">
                  Selecione um personagem para ver suas cartas
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                {characters.map((character) => (
                  <Button
                    key={character}
                    variant={selectedCharacter === character ? "default" : "outline"}
                    className={`w-full justify-start ${
                      selectedCharacter === character 
                        ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                        : 'bg-white/10 hover:bg-white/20 text-white border-white/20'
                    }`}
                    onClick={() => {
                      setSelectedCharacter(character)
                      setSelectedCard(null)
                      setSearchTerm('')
                    }}
                  >
                    {character}
                    <Badge variant="secondary" className="ml-auto">
                      {characterDecks[character]?.length || 0}
                    </Badge>
                  </Button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Cards List */}
          <div className="lg:col-span-2">
            {selectedCharacter ? (
              <Card className="bg-black/20 backdrop-blur-sm border-white/10">
                <CardHeader>
                  <CardTitle className="text-white">
                    Cartas de {selectedCharacter}
                  </CardTitle>
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Buscar cartas..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                    />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {filteredCards.map((card) => (
                      <div
                        key={card.id}
                        className="p-3 rounded-lg bg-white/5 hover:bg-white/10 cursor-pointer transition-colors border border-white/10"
                        onClick={() => setSelectedCard(card)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <div className={`p-1 rounded ${getCardTypeColor(card.type)}`}>
                              {getCardTypeIcon(card.type)}
                            </div>
                            <div>
                              <h3 className="font-medium text-white">{card.name}</h3>
                              <p className="text-sm text-blue-200">{card.type}</p>
                            </div>
                          </div>
                          {card.atk !== undefined && (
                            <div className="text-right">
                              <p className="text-sm text-white">ATK: {card.atk}</p>
                              {card.def !== undefined && (
                                <p className="text-sm text-blue-200">DEF: {card.def}</p>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                    {filteredCards.length === 0 && (
                      <p className="text-center text-gray-400 py-8">
                        {searchTerm ? 'Nenhuma carta encontrada' : 'Nenhuma carta disponível'}
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-black/20 backdrop-blur-sm border-white/10">
                <CardContent className="flex items-center justify-center h-96">
                  <div className="text-center">
                    <Zap className="w-16 h-16 text-blue-400 mx-auto mb-4" />
                    <h3 className="text-xl font-medium text-white mb-2">
                      Selecione um Personagem
                    </h3>
                    <p className="text-blue-200">
                      Escolha um personagem à esquerda para ver suas cartas
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Card Details */}
          <div className="lg:col-span-1">
            {selectedCard ? (
              <Card className="bg-black/20 backdrop-blur-sm border-white/10">
                <CardHeader>
                  <CardTitle className="text-white text-lg">
                    {selectedCard.name}
                  </CardTitle>
                  <Badge className={getCardTypeColor(selectedCard.type)}>
                    {selectedCard.type}
                  </Badge>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Card Image */}
                  {selectedCard.card_images && selectedCard.card_images[0] && (
                    <div className="aspect-[3/4] bg-white/5 rounded-lg overflow-hidden">
                      <img
                        src={selectedCard.card_images[0].image_url}
                        alt={selectedCard.name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.target.style.display = 'none'
                        }}
                      />
                    </div>
                  )}
                  
                  {/* Card Stats */}
                  {selectedCard.atk !== undefined && (
                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-white/5 p-2 rounded">
                        <p className="text-xs text-blue-200">ATK</p>
                        <p className="font-bold text-white">{selectedCard.atk}</p>
                      </div>
                      {selectedCard.def !== undefined && (
                        <div className="bg-white/5 p-2 rounded">
                          <p className="text-xs text-blue-200">DEF</p>
                          <p className="font-bold text-white">{selectedCard.def}</p>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {selectedCard.level && (
                    <div className="bg-white/5 p-2 rounded">
                      <p className="text-xs text-blue-200">Level/Rank</p>
                      <p className="font-bold text-white">{selectedCard.level}</p>
                    </div>
                  )}
                  
                  {selectedCard.attribute && (
                    <div className="bg-white/5 p-2 rounded">
                      <p className="text-xs text-blue-200">Attribute</p>
                      <p className="font-bold text-white">{selectedCard.attribute}</p>
                    </div>
                  )}
                  
                  {selectedCard.race && (
                    <div className="bg-white/5 p-2 rounded">
                      <p className="text-xs text-blue-200">Type</p>
                      <p className="font-bold text-white">{selectedCard.race}</p>
                    </div>
                  )}
                  
                  {/* Card Description */}
                  <div className="bg-white/5 p-3 rounded">
                    <p className="text-xs text-blue-200 mb-1">Description</p>
                    <p className="text-sm text-white leading-relaxed">
                      {selectedCard.desc}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-black/20 backdrop-blur-sm border-white/10">
                <CardContent className="flex items-center justify-center h-96">
                  <div className="text-center">
                    <Star className="w-16 h-16 text-purple-400 mx-auto mb-4" />
                    <h3 className="text-xl font-medium text-white mb-2">
                      Detalhes da Carta
                    </h3>
                    <p className="text-blue-200">
                      Clique em uma carta para ver seus detalhes
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default App
