# Yu-Gi-Oh! Card Database - Visualizador de Cartas por Personagens

## Descrição

Este é um website completo para visualizar cartas de Yu-Gi-Oh! organizadas por personagens dos animes Yu-Gi-Oh! e Yu-Gi-Oh! GX. O projeto oferece uma interface moderna e intuitiva para explorar as cartas icônicas de cada personagem.

## Funcionalidades

### ✨ Principais Recursos

- **Navegação por Personagens**: Selecione entre os principais personagens dos animes Yu-Gi-Oh! e Yu-Gi-Oh! GX
- **Visualização de Cartas**: Explore todas as cartas associadas a cada personagem
- **Busca Inteligente**: Sistema de busca em tempo real para encontrar cartas específicas
- **Detalhes Completos**: Visualize informações detalhadas de cada carta, incluindo:
  - Imagem oficial da carta
  - ATK/DEF (para monstros)
  - Level/Rank
  - Atributo
  - Tipo
  - Descrição completa do efeito

### 🎨 Design e Interface

- **Design Responsivo**: Funciona perfeitamente em desktop e dispositivos móveis
- **Tema Escuro Moderno**: Interface com gradiente azul-roxo inspirado no universo Yu-Gi-Oh!
- **Animações Suaves**: Transições e hover effects para uma experiência fluida
- **Ícones Intuitivos**: Diferentes ícones para tipos de cartas (Monstro, Magia, Armadilha)

## Personagens Incluídos

### Yu-Gi-Oh! (Duel Monsters)
- **Yugi Muto** - 53 cartas (Dark Magician archetype)
- **Seto Kaiba** - 40 cartas (Blue-Eyes archetype)
- **Joey Wheeler** - 39 cartas (Red-Eyes archetype)

### Yu-Gi-Oh! GX
- **Jaden Yuki** - 134 cartas (Elemental HERO archetype)
- **Zane Truesdale** - 27 cartas (Cyber Dragon archetype)
- **Chazz Princeton** - 40 cartas (Ojama/Armed Dragon archetypes)

## Tecnologias Utilizadas

- **Frontend**: React 18 com Vite
- **Styling**: Tailwind CSS + shadcn/ui components
- **Ícones**: Lucide React
- **API**: YGOPRODeck API v7 para dados das cartas
- **Build**: Vite para otimização e bundling

## Estrutura do Projeto

```
yugioh-card-viewer/
├── src/
│   ├── assets/
│   │   └── character_decks.json    # Dados processados das cartas
│   ├── components/
│   │   └── ui/                     # Componentes shadcn/ui
│   ├── App.jsx                     # Componente principal
│   ├── App.css                     # Estilos customizados
│   └── main.jsx                    # Ponto de entrada
├── dist/                           # Build de produção
└── package.json                    # Dependências do projeto
```

## Como Usar

1. **Selecione um Personagem**: Clique em qualquer personagem na barra lateral esquerda
2. **Explore as Cartas**: Navegue pela lista de cartas do personagem selecionado
3. **Busque Cartas**: Use o campo de busca para filtrar cartas por nome
4. **Veja Detalhes**: Clique em qualquer carta para ver suas informações completas

## Dados das Cartas

O projeto utiliza a API oficial do YGOPRODeck (v7) que fornece:
- Informações completas de mais de 12.000 cartas
- Imagens oficiais em alta qualidade
- Dados atualizados regularmente
- Suporte a múltiplos idiomas

## Performance e Otimização

- **Lazy Loading**: Carregamento otimizado de imagens
- **Filtragem Client-side**: Busca instantânea sem requisições adicionais
- **Bundle Otimizado**: Build minificado para carregamento rápido
- **Responsive Design**: Interface adaptável a qualquer tamanho de tela

## Deployment

O projeto está pronto para deployment e pode ser facilmente hospedado em qualquer serviço de hosting estático como:
- Vercel
- Netlify
- GitHub Pages
- Firebase Hosting

---

**Desenvolvido com ❤️ para fãs de Yu-Gi-Oh!**

