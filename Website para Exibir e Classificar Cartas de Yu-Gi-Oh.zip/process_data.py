

import json

# Carregar os dados das cartas
with open('all_cards.json', 'r') as f:
    all_cards = json.load(f)

# Estrutura para armazenar os decks dos personagens
character_decks = {
    'Yugi Muto': [],
    'Seto Kaiba': [],
    'Joey Wheeler': [],
    'Jaden Yuki': [],
    'Zane Truesdale': [],
    'Chazz Princeton': [],
}

# Mapeamento de arquétipos para personagens
archetype_map = {
    'Dark Magician': 'Yugi Muto',
    'Blue-Eyes': 'Seto Kaiba',
    'Red-Eyes': 'Joey Wheeler',
    'Elemental HERO': 'Jaden Yuki',
    'Cyber Dragon': 'Zane Truesdale',
    'Ojama': 'Chazz Princeton',
    'Armed Dragon': 'Chazz Princeton',
}

# Processar cada carta
for card_data in all_cards['data']:
    if 'archetype' in card_data:
        archetype = card_data['archetype']
        if archetype in archetype_map:
            character = archetype_map[archetype]
            character_decks[character].append(card_data)

# Salvar os dados processados em um novo arquivo JSON
with open('character_decks.json', 'w') as f:
    json.dump(character_decks, f, indent=4)

print('Dados processados e salvos em character_decks.json')


