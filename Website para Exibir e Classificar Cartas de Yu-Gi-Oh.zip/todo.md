- [x] Pesquisar dados de cartas e personagens
- [x] Coletar imagens de cartas e personagens
- [x] Estruturar dados e criar base de dados
- [x] Desenvolver interface do website
- [x] Implementar funcionalidades interativas
- [x] Testar e otimizar o website
- [x] Entregar resultado final ao usuário

